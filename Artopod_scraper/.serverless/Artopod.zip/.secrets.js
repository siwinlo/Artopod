const RDSTokens = {
  artopodRDSPassword: `FQVC1boTjm8fjjEQ2t4u`,
  artopodRDSHost: `artopod-db.ccsldvj96dsk.us-east-1.rds.amazonaws.com`,
  artopodRDSUsername: `postgres`,
  artopodRDSPort: `5432`,
  artopodRDSDatabase: `artopod`
};

module.exports = RDSTokens;
